import { LogOut, Menu, Settings } from 'lucide-react'
import { useState } from 'react'
import toast from 'react-hot-toast'
import { useAuth } from '../../hooks/useAuth'
import Avatar from '../UI/Avatar'
import ThemeToggle from '../UI/ThemeToggle'
import BrandingSettings from './BrandingSettings'
import { useBranding } from '../../hooks/useBranding'

export default function Header({ onOpenSidebar }) {
  const { profile, user, role, signOut } = useAuth()
  const { branding } = useBranding()
  const [brandingOpen, setBrandingOpen] = useState(false)

  const handleLogout = async () => {
    try {
      await signOut()
      toast.success('Déconnexion réussie')
    } catch (err) {
      toast.error(`Erreur lors de la déconnexion : ${err.message}`)
    }
  }

  return (
    <header className="navbar min-h-16 bg-base-200 border-b border-base-300 px-3 sm:px-4">
      <div className="flex-1 flex items-center gap-2">
        <button
          className="btn btn-ghost btn-circle lg:hidden"
          onClick={onOpenSidebar}
          aria-label="Ouvrir le menu"
        >
          <Menu className="w-5 h-5" />
        </button>
        <img
          src={branding.logo}
          alt="Estime Parfum"
          className="h-11 w-auto object-contain sm:h-14"
        />
        {branding.showTextInHeader && (
          <span className="truncate text-base font-semibold sm:text-lg">{branding.text}</span>
        )}
      </div>

      <div className="flex shrink-0 items-center gap-1 sm:gap-3">
        <ThemeToggle />
        <button
          className="btn btn-ghost btn-circle"
          onClick={() => setBrandingOpen(true)}
          aria-label="Personnaliser le logo et le texte"
          title="Personnaliser le logo et le texte"
        >
          <Settings className="h-5 w-5" />
        </button>
        <div className="flex items-center gap-2">
          <Avatar src={profile?.avatar_url} name={profile?.full_name || user?.email} size={9} />
          <div className="hidden sm:flex flex-col leading-tight">
            <span className="text-sm font-medium">{profile?.full_name || user?.email}</span>
            {role && (
              <span
                className={`badge badge-sm ${role === 'admin' ? 'badge-primary' : 'badge-ghost'}`}
              >
                {role}
              </span>
            )}
          </div>
        </div>
        <button
          className="btn btn-ghost btn-circle"
          onClick={handleLogout}
          aria-label="Se déconnecter"
        >
          <LogOut className="w-5 h-5" />
        </button>
      </div>
      <BrandingSettings open={brandingOpen} onClose={() => setBrandingOpen(false)} />
    </header>
  )
}
