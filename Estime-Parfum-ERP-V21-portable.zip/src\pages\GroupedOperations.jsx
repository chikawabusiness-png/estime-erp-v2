import { useState } from 'react'
import EntityPage from '../components/ERP/EntityPage'
import { CONFIG } from './ERPModules'
import InventoryCatalog from './InventoryCatalog'

const GROUPS = {
  stock: {
    title: 'Stock & Production',
    tabs: [
    { key: 'catalog', label: 'Inventaire', component: InventoryCatalog },
    { key: 'production', label: 'Production', config: CONFIG.production },
      { key: 'purchases', label: 'Achats', config: CONFIG.purchases }
    ]
  },
  logistics: {
    title: 'Livraisons & Retours',
    tabs: [
      { key: 'deliveries', label: 'Livraisons', config: CONFIG.deliveries },
      { key: 'returns', label: 'Retours', config: CONFIG.returns }
    ]
  }
}

export default function GroupedOperations({ group }) {
  const configuration = GROUPS[group]
  const [activeTab, setActiveTab] = useState(configuration.tabs[0].key)
  const active = configuration.tabs.find((tab) => tab.key === activeTab)
  const ActiveComponent = active.component || EntityPage

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold">{configuration.title}</h1>
        <div role="tablist" className="tabs tabs-boxed mt-4 w-fit max-w-full flex-wrap">
          {configuration.tabs.map((tab) => (
            <button
              key={tab.key}
              type="button"
              role="tab"
              aria-selected={activeTab === tab.key}
              className={`tab ${activeTab === tab.key ? 'tab-active' : ''}`}
              onClick={() => setActiveTab(tab.key)}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>
      {active.config ? <ActiveComponent {...active.config} /> : <ActiveComponent />}
    </div>
  )
}
