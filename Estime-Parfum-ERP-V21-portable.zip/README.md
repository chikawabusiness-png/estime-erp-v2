# Estime Parfum ERP

ERP complet pour une boutique de parfums : React + Vite (Netlify), Supabase (Postgres, Auth, Storage, RLS, Edge Functions), Tailwind + DaisyUI. Entièrement sur offres gratuites.

## 1. Déploiement

1. **Créer le projet Supabase** (gratuit) → récupérez `SUPABASE_URL`, `SUPABASE_ANON_KEY`, `SUPABASE_SERVICE_ROLE_KEY`, `SUPABASE_PROJECT_REF`, et générez un jeton d'accès personnel (`SUPABASE_ACCESS_TOKEN`) depuis votre compte Supabase.
2. **Créer le site Netlify** (gratuit) → récupérez `NETLIFY_SITE_ID` et un jeton d'accès personnel (`NETLIFY_AUTH_TOKEN`).
3. **Ajouter tous les secrets** dans GitHub → *Settings → Secrets and variables → Actions* :
   `VITE_SUPABASE_URL`, `VITE_SUPABASE_ANON_KEY`, `SUPABASE_ACCESS_TOKEN`, `SUPABASE_PROJECT_REF`, `NETLIFY_AUTH_TOKEN`, `NETLIFY_SITE_ID`.
4. **Pousser le dépôt** : `git push origin main`. Le workflow GitHub Actions va automatiquement :
   - builder le front-end,
   - créer/mettre à jour le schéma de base de données et les politiques RLS,
   - déployer l'Edge Function `adjust_stock`,
   - publier le site statique sur Netlify.
5. **Accéder à l'ERP** sur `https://<NETLIFY_SITE_ID>.netlify.app`.

Après le premier déploiement, créez un compte via `/inscription`, puis passez son `role` à `admin` directement dans la table `profiles` (Supabase Studio) pour débloquer la gestion des produits/factures.

### Alertes Telegram

La migration `supabase/migrations/202609170004_telegram_alerts.sql` met les événements
produits/stock, commandes, paiements, livraisons et retours dans une file sécurisée.
Déployez ensuite `supabase/functions/telegram-alerts` et configurez uniquement côté Supabase :

```text
TELEGRAM_BOT_TOKEN
TELEGRAM_CHAT_ID
```

Appelez la fonction après les opérations métier ou planifiez son exécution périodique.
Le token Telegram ne doit jamais être placé dans `.env` frontend ou dans le code client.

## 2. Test en local

- `npm install` puis `cp .env.example .env` et remplissez `VITE_SUPABASE_URL` / `VITE_SUPABASE_ANON_KEY`.
- `npm run dev` → vérifier l'UI, l'inscription/connexion, le mode sombre, la navigation.
- Ouvrir Supabase Studio pour visualiser les tables créées par la migration.
- Créer un produit, téléverser une image, vérifier son apparition dans le bucket `product-images`.
- Créer une commande, vérifier que le stock est décrémenté et qu'une ligne apparaît dans `stock_movements`.
- Cliquer sur *Exporter* → le fichier Excel se télécharge.
- `npm run supabase:push` et `npm run supabase:func:deploy` pour tester les étapes de CI localement (nécessite `SUPABASE_PROJECT_REF` et d'être connecté via `supabase login`).

## 3. Pistes d'évolution

- UI par rôle plus poussée (l'admin gère les utilisateurs, les vendeurs uniquement les commandes).
- Notifications email via SendGrid (Netlify Function).
- Génération de factures PDF avec `pdf-lib` (Netlify Function, stockage dans le bucket `invoices`).
- Alertes de stock bas planifiées (Netlify Function / cron Supabase) envoyées vers Slack ou un webhook.
- Tableau de bord analytique avancé (Chart.js, vues matérialisées pour le chiffre d'affaires mensuel).
